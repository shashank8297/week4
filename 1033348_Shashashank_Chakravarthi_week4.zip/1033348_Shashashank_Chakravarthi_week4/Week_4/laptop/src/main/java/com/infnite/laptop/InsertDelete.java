package com.infnite.laptop;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class InsertDelete {
	@RequestMapping(value="/inserttable", method=RequestMethod.POST)
	public String inserttable(HttpServletRequest request, HttpServletResponse Respose)
	{
		
		String modelno = request.getParameter("modelno");
		String modelname = request.getParameter("modelname");
		String date = request.getParameter("date");
		int cost = Integer.parseInt(request.getParameter("cost"));
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/laptop", "root","mysql123@");
			PreparedStatement ps = conn.prepareStatement("insert into lenovo values(?,?,?,?)");
			
			ps.setString(1,modelno);
			ps.setString(2,modelname);
			ps.setString(3,date);
			ps.setInt(4,cost);
			ResultSet rs = ps.executeQuery();
			if(rs.next()){
				return "success";
				//return 
			}
			else{
				//redirect
				return "fail";
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				//conn.close();
				System.out.println("Connection closed");
			} 
			catch (Exception e) 
			{
				System.out.println(e);
			}
		}
		return null;
	}
	@RequestMapping(value="/deletetable", method=RequestMethod.POST)
	public String deletetable(HttpServletRequest request, HttpServletResponse Respose)
	{
		ResultSet rs = null;
		String modelno = request.getParameter("modelno");
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/laptop", "root","mysql123@");
			PreparedStatement ps = conn.prepareStatement("select modelno from lenovo where modelno=?");
			
			ps.setString(1,modelno);
			rs = ps.executeQuery();
			if(rs.next()){
				PreparedStatement ps1 = conn.prepareStatement("delete from lenovo where modelno=?");
				int x = ps1.executeUpdate();
				if(x!=0)
				{
					return "success";
				//return
				}
			}
			else{
				//redirect
				return "fail";
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				//conn.close();
				System.out.println("Connection closed");
			} 
			catch (Exception e) 
			{
				System.out.println(e);
			}
		}
		return null;
	}
}
