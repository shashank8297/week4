package com.infnite.laptop;

import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Lenovo {
	@RequestMapping("/home")
	public String home(){
		System.out.println("home");
		return "home";
	}
	@RequestMapping(value="/insert")
	public String insert(){
		System.out.println("insert");
		return "insert";
	}
	@RequestMapping("/delete")
	public String delete(){
		System.out.println("delete");
		return "delete";
	}
}
